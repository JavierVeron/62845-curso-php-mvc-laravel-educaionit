Patrones de creacion:<br>
<a href="./factory.php">Factory pattern</a> <br>
<a href="./prototype.php">Prototype pattern</a> <br>
<a href="./singleton.php">Singleton pattern</a><br>

Patrones de estructura:<br>
<a href="./adapter.php">Adapter pattern</a> <br>
<a href="./decorator.php">Decorator pattern</a> <br>
<a href="./facade.php">Facade pattern</a><br>

Patrones de comportamiento:<br>
<a href="./iterator.php">Iterator pattern</a> <br>
<a href="./observer.php">Observer pattern</a> <br>
<a href="./strategy.php">Strategy pattern</a><br>