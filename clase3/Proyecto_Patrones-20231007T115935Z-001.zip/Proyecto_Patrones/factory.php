<?php

interface vehiculo{
	function getNombre();
}

class Avion implements vehiculo
{
	public function getNombre(){
		return 'Soy un avion';
	}
}

class Automovil implements vehiculo
{
	public function getNombre(){
		return 'Soy un automovil';
	}
}

class VehiculoFactory
{
    public static function create($tipodevehiculo)
    {
		switch($tipodevehiculo){
			case "automovil":
			return new Automovil();break;
			case "avion": 
			return new Avion();break;
		}
    }
}

$auto = VehiculoFactory::create("automovil");
$avion = VehiculoFactory::create("avion");

echo $auto->getNombre();
echo '<br>';
echo $avion->getNombre();
